% ELEC 4700 Assignment 4 Question 3
% Liam Anderson 100941879
% Submission April 5 2020

clear;

Cap = 0.25;
L = 0.2;

G = [
    1.0000   -1.0000         0         0         0         0         0    1.0000    ;
   -1.0000    1.5000         0         0         0    1.0000         0         0    ;
         0         0    0.1000         0         0   -1.0000         0         0    ;
         0         0         0   10.0000  -10.0000         0    1.0000         0    ;
         0         0         0  -10.0000   10.0010         0         0         0    ;
         0    1.0000   -1.0000         0         0         0         0         0    ;
         0         0  -10.0000    1.0000         0         0         0         0    ;
    1.0000         0         0         0         0         0         0         0    ;
    ];
    
C = [
       Cap      -Cap         0         0         0         0         0         0    ;
      -Cap       Cap         0         0         0         0         0         0    ;
         0         0         0         0         0         0         0         0    ;
         0         0         0         0         0         0         0         0    ;
         0         0         0         0         0         0         0         0    ;
         0         0         0         0         0        -L         0         0    ;
         0         0         0         0         0         0         0         0    ;
         0         0         0         0         0         0         0         0    ;
    ];

F = [
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    1   ;
    ];


% DC Sweep
V3 = [];
V5 = [];
for Vin = -10:0.1:10
    F(8) = Vin; % Set DC voltage
    % Solve for DC
    v = G\F;
    V3 = [V3 v(3)];
    V5 = [V5 v(5)];
end

figure(1);
hold on;
title('DC Sweep');
xlabel('Vin (V)');
ylabel('Voltage (V)');
plot(-10:0.1:10, V3);
plot(-10:0.1:10, V5);

% AC Sweep
V5 = [];
Gain = [];
F(8) = 10; % dc

% AC: Vout
for w=10:100000
    e = (G+2*pi*w*1j*C)\F;
    V5 = [V5 20*log10(abs(e(5)))];
end

figure(2);
plot(10:100000, V5);
title('AC Sweep');
xlabel('freq');
ylabel('Vo');

% AC: Gain
for w=10:100000
    e = (G+2*pi*w*1j*C)\F;
    Gain = [Gain 20*log10(abs(e(5)/F(8)))];
end

figure(3);
semilogx(10:100000, Gain); % log -> db
%plot(10:100000, Gain);
title('AC Sweep');
xlabel('freq');
ylabel('Gain (db)');


% Capacitor Sweep
V5 = [];
F(8) = 10;
std = 0.05;
w = 3.14159;

for i = 1:2000
    caprand = normrnd(Cap,0.05);
    C = [
           caprand   -caprand    0         0         0         0         0         0    ;
           -caprand   caprand         0         0         0         0         0         0    ;
             0         0         0         0         0         0         0         0    ;
             0         0         0         0         0         0         0         0    ;
             0         0         0         0         0         0         0         0    ;
             0         0         0         0         0        -L         0         0    ;
             0         0         0         0         0         0         0         0    ;
             0         0         0         0         0         0         0         0    ;
        ];
    e = (G+2*pi*w*1j*C)\F;
    V5 = [V5 20*log10(abs(e(5)/F(8)))];
end

histogram(V5);
title('Cap sweep');
