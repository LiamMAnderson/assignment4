% ELEC 4700 Assignment 4 Question 5
% Liam Anderson 100941879
% Submission April 5 2020

clear;

Cap = 0.25;
L = 0.2;

In = 0.001;
Cnew = 0.00001;

steps = 1000;
time = 1;
dt = time/steps;

G = [
    1.0000   -1.0000         0         0         0         0         0    1.0000    ;
   -1.0000    1.5000         0         0         0    1.0000         0         0    ;
         0         0    0.1000         0         0   -1.0000         0         0    ;
         0         0         0   10.0000  -10.0000         0    1.0000         0    ;
         0         0         0  -10.0000   10.0010         0         0         0    ;
         0    1.0000   -1.0000         0         0         0         0         0    ;
         0         0  -10.0000    1.0000         0         0         0         0    ;
    1.0000         0         0         0         0         0         0         0    ;
    ];

C = [
       Cap      -Cap         0         0         0         0         0         0    ;
      -Cap       Cap         0         0         0         0         0         0    ;
         0         0      Cnew         0         0         0         0         0    ;
         0         0         0         0         0         0         0         0    ;
         0         0         0         0         0         0         0         0    ;
         0         0         0         0         0        -L         0         0    ;
         0         0         0         0         0         0         0         0    ;
         0         0         0         0         0         0         0         0    ;
    ];

F = [
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    ];

V = zeros(8,1);

transient = C/dt + G;

index = 1;
for t = 0:dt:1
    F(8) = exp(-1*((t - 0.06)/0.03)^2);
    F(3) = In*normrnd(0,1);
    V = transient\(C*V/dt + F);
    Vi(index) = V(1);
    Vo(index) = V(5);
    index = index + 1;
end

% Plot
figure(1)
plot(0:dt:1,Vi)
hold on
plot(0:dt:1,Vo)
grid on;
xlabel('Time s')
ylabel('Voltage v')
title('C = 0.00001 Gaussian Pulse')
legend('Vin','Vout')
hold off

% Fourier
figure(2)
FF = abs(fftshift(fft(Vo)));
plot(((1:length(FF))/steps)-0.5,FF)
xlim([-0.03 0.03])
xlabel('Freq.')
ylabel('Mag. (dB)')
title('C = 0.00001 GP Fourier')

% Varying Capacitor
% Variation #1 C = 0.001
C1 = C;
C1(3,3) = 0.001;
V1 = zeros(8,1);
In1 = 0.001;

F1 = [
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    ];

transient1 = C1/dt + G;

index = 1;
for t = 0:dt:1
    F1(8) = exp(-1*((t - 0.06)/0.03)^2);
    F1(3) = In1*normrnd(0,1);
    V1 = transient1\(C1*V1/dt + F1);
    Vi1(index) = V1(1);
    Vo1(index) = V1(5);
    index = index + 1;
end

figure(3)
plot(0:dt:1,Vi1)
hold on
plot(0:dt:1,Vo1)
grid on;
xlabel('Time s')
ylabel('Voltage v')
title('Varying C: C = 0.001')
legend('Vin','Vout')
hold off

figure(4)
FF1 = abs(fftshift(fft(Vo1)));
plot(((1:length(FF1))/steps)-0.5,FF1)
xlim([-0.03 0.03])
xlabel('Freq.')
ylabel('Mag. (dB)')
title('C = 0.001 Fourier Transform')

% Variation #2 C = 0.01
C2 = C;
C2(3,3) = 0.01;
V2 = zeros(8,1);
In2 = 0.01; % more noise to be visible on graph

F2 = [
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    ];

transient2 = C2/dt + G;

index = 1;
for t = 0:dt:1
    F2(8) = exp(-1*((t - 0.06)/0.03)^2);
    F2(3) = In2*normrnd(0,1);
    V2 = transient2\(C2*V2/dt + F2);
    Vi2(index) = V2(1);
    Vo2(index) = V2(5);
    index = index + 1;
end

figure(5)
plot(0:dt:1,Vi2)
hold on
plot(0:dt:1,Vo2)
grid on;
xlabel('Time s')
ylabel('Voltage v')
title('Varying C: C = 0.01')
legend('Vin','Vout')
hold off

figure(6)
FF2 = abs(fftshift(fft(Vo2)));
plot(((1:length(FF2))/steps)-0.5,FF2)
xlim([-0.015 0.015])
xlabel('Freq.')
ylabel('Mag. (dB)')
title('C = 0.01 Fourier Transform')


% Varying Timestep (x2)
% Variation #1 timestep = 500
V = zeros(8,1);

dt1 = 5e-2;

transient = C/dt1 + G;

index = 1;
for t = 0:dt1:1
    F(8) = exp(-1*((t - 0.06)/0.03)^2);
    F(3) = In*normrnd(0,1);
    V = transient\(C*V/dt1 + F);
    Vinewdt(index) = V(1);
    Vonewdt(index) = V(5);
    index = index + 1;
end

% Plot
figure(7)
plot(0:dt1:1,Vinewdt)
hold on
plot(0:dt1:1,Vonewdt)
grid on;
xlabel('Time s')
ylabel('Voltage v')
title('Varying timestep: times 50')
legend('Vin','Vout')
hold off

% Variation #2 timestep = 100
V = zeros(8,1);

dt2 = 1e-1;

transient = C/dt2 + G;

index = 1;
for t = 0:dt2:1
    F(8) = exp(-1*((t - 0.06)/0.03)^2);
    F(3) = In*normrnd(0,1);
    V = transient\(C*V/dt2 + F);
    Vinewdt2(index) = V(1);
    Vonewdt2(index) = V(5);
    index = index + 1;
end

% Plot
figure(8)
plot(0:dt2:1,Vinewdt2)
hold on
plot(0:dt2:1,Vonewdt2)
grid on;
xlabel('Time s')
ylabel('Voltage v')
title('Varying timestep: times 100')
legend('Vin','Vout')
hold off

% Variation #3 timestep = 10000
V = zeros(8,1);

dt3 = 1e-4;

transient = C/dt3 + G;

index = 1;
for t = 0:dt3:1
    F(8) = exp(-1*((t - 0.06)/0.03)^2);
    F(3) = In*normrnd(0,1);
    V = transient\(C*V/dt3 + F);
    Vinewdt3(index) = V(1);
    Vonewdt3(index) = V(5);
    index = index + 1;
end

% Plot
figure(9)
plot(0:dt3:1,Vinewdt3)
hold on
plot(0:dt3:1,Vonewdt3)
grid on;
xlabel('Time s')
ylabel('Voltage v')
title('Varying timestep: divided by 10')
legend('Vin','Vout')
hold off

