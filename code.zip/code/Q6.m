% ELEC 4700 Assignment 4 Question 6
% Liam Anderson 100941879
% Submission April 5 2020

clear;

% The simulation now needs to deal with nonlinearity.
% A new vector would be added to the matrix equation.
% Gaussian can no longer be used for this non-linear
% problem so some other algorithm would have to be used.





