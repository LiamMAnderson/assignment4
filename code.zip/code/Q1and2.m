% ELEC 4700 Assignment 4 Question 1 & 2
% Liam Anderson 100941879
% Submission April 5 2020

% My assignment 3 was terrible...
% But if I had the IV data from A3 I would
% find the linear fit and R3 like this:

poly = polyfit(v, i, 1);
fit = poly(1)*v + poly(2);
R3 = poly(1)

