% ELEC 4700 Assignment 4 Question 4
% Liam Anderson 100941879
% Submission April 5 2020

clear;

Cap = 0.25;
L = 0.2;

G = [
    1.0000   -1.0000         0         0         0         0         0    1.0000    ;
   -1.0000    1.5000         0         0         0    1.0000         0         0    ;
         0         0    0.1000         0         0   -1.0000         0         0    ;
         0         0         0   10.0000  -10.0000         0    1.0000         0    ;
         0         0         0  -10.0000   10.0010         0         0         0    ;
         0    1.0000   -1.0000         0         0         0         0         0    ;
         0         0  -10.0000    1.0000         0         0         0         0    ;
    1.0000         0         0         0         0         0         0         0    ;
    ];
    
C = [
       Cap      -Cap         0         0         0         0         0         0    ;
      -Cap       Cap         0         0         0         0         0         0    ;
         0         0         0         0         0         0         0         0    ;
         0         0         0         0         0         0         0         0    ;
         0         0         0         0         0         0         0         0    ;
         0         0         0         0         0        -L         0         0    ;
         0         0         0         0         0         0         0         0    ;
         0         0         0         0         0         0         0         0    ;
    ];

F = [
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    0   ;
    ];

steps = 1000;
time = 1;
dt = time/steps;

transient = C/dt + G;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step
Fstep = zeros(8,1);
Vstep = zeros(8,1);
index = 1;
for t = 0:dt:1
    if t >= 0.03
        Fstep(8) = 3;
    end
    Vstep = transient\(C*Vstep/dt + Fstep);
    Vi(index) = Vstep(1);
    Vo(index) = Vstep(5);
    index = index + 1;
end

% Step Plot
figure(1)
plot(0:dt:1,Vi)
hold on
plot(0:dt:1,Vo)
xlabel('s')
ylabel('V')
title('Step')

% Step Fourier
figure(2)
FF = abs(fftshift(fft(Vo)));
plot(((1:length(FF))/steps)-0.5,FF)
xlim([-0.03 0.03])
xlabel('Freq.')
ylabel('Mag (dB)')
title('Step Fourier Transform')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sine
Fsine = zeros(8,1);
Vsine = zeros(8,1);
index = 1;
for t = 0:dt:1
    Fsine(8) = sin(2*pi*t/0.03);
    Vsine = transient\(C*Vsine/dt + Fsine);
    Visine(index) = Vsine(1);
    Vosine(index) = Vsine(5);
    index = index + 1;
end

% Sine Plot
figure(3)
plot(0:dt:1,Visine)
hold on
plot(0:dt:1,Vosine)
xlabel('Time s')
ylabel('Voltage V')
title('Sine with f = 1/0.003')

% Sine Fourier
figure(4)
FF = abs(fftshift(fft(Vosine)));
plot(((1:length(FF))/steps)-0.5,FF)
xlim([-0.1 0.1])
xlabel('Freq.')
ylabel('Mag (dB)')
title('Sine with f = 1/0.003 Fourier Transform')

% Sine VARIATION: f = 1/0.1
Fsine = zeros(8,1);
Vsine = zeros(8,1);
index = 1;
for t = 0:dt:1
    Fsine(8) = sin(2*pi*t/0.1);
    Vsine = transient\(C*Vsine/dt + Fsine);
    Visine(index) = Vsine(1);
    Vosine(index) = Vsine(5);
    index = index + 1;
end

% Sine Plot variation 1
figure(5)
plot(0:dt:1,Visine)
hold on
plot(0:dt:1,Vosine)
xlabel('s')
ylabel('V')
title('Sine with f = 1/0.1')

% Sine Fourier variation 1
figure(6)
FF = abs(fftshift(fft(Vosine)));
plot(((1:length(FF))/steps)-0.5,FF)
xlim([-0.1 0.1])
title('Sine with f = 1/0.1 Fourier Transform')
xlabel('Freq.')
ylabel('Mag (dB)')

% Sine VARIATION 2: f = 1/0.3
Fsine = zeros(8,1);
Vsine = zeros(8,1);
index = 1;
for t = 0:dt:1
    Fsine(8) = sin(2*pi*t/0.3);
    Vsine = transient\(C*Vsine/dt + Fsine);
    Visine(index) = Vsine(1);
    Vosine(index) = Vsine(5);
    index = index + 1;
end

% Sine Plot variation 2
figure(7)
plot(0:dt:1,Visine)
hold on
plot(0:dt:1,Vosine)
xlabel('s')
ylabel('V')
title('Sine with f = 1/0.3')

% Sine Fourier variation 2
figure(8)
FF = abs(fftshift(fft(Vosine)));
plot(((1:length(FF))/steps)-0.5,FF)
xlim([-0.1 0.1])
xlabel('Freq.')
ylabel('Mag (dB)')
title('Sine with f = 1/0.3 Fourier Transform')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Gaussian Pulse
Fgp = zeros(8,1);
Vgp = zeros(8,1);
index = 1;
for t = 0:dt:1
    Fgp(8) = exp(-1*((t-0.06)/0.03)^2);
    Vgp = transient\(C*Vgp/dt + Fgp);
    Vigp(index) = Vgp(1);
    Vogp(index) = Vgp(5);
    index = index + 1;
end

% GP Plot
figure(9)
plot(0:dt:1,Vigp)
hold on
plot(0:dt:1,Vogp)
xlabel('s')
ylabel('V')
title('Gaussian Pulse')

% GP Fourier
figure(10)
FF = abs(fftshift(fft(Vogp)));
plot(((1:length(FF))/steps)-0.5,FF)
xlim([-0.03 0.03])
xlabel('Freq.')
ylabel('Mag (dB)')
title('Gaussian Pulse Fourier Transform')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



